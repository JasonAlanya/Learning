package com.company;

public class Main {
    public static void main (String[] args){

        Cliente pedro = new Cliente();
        pedro.setEdad(32);
        pedro.setTelefono("955879487");
        pedro.setNombre("Pedro");
        pedro.setCredito(700);

        System.out.println("El usuario "+pedro.getNombre()+" tiene la edad de "+pedro.getEdad()+
                " años, se le puede contactar mediante el número: "+ pedro.getTelefono()
                +" y actualmente tiene un credito de: "+pedro.getCredito());

        Trabajador maria = new Trabajador();
        maria.setEdad(20);
        maria.setTelefono("958784574");
        maria.setNombre("Maria");
        maria.setSalario(1000);

        System.out.println("El usuario "+maria.getNombre()+" tiene la edad de "+maria.getEdad()+
                " años, se le puede contactar mediante el número: "+ maria.getTelefono()
                +" y actualmente tiene un salario de: "+maria.getSalario());
    }
}

class Persona{
    private int edad;
    private String nombre;
    private String telefono;

    public int getEdad(){
        return this.edad;
    }

    public String getNombre(){
        return this.nombre;
    }

    public String getTelefono(){
        return this.telefono;
    }

    public void setEdad(int edad){
        this.edad=edad;
    }

    public void setNombre(String nombre){
        this.nombre=nombre;
    }

    public void setTelefono(String telefono){
        this.telefono=telefono;
    }
}

class Cliente extends Persona{
    private float credito;

    public float getCredito(){
        return this.credito;
    }

    public void setCredito(float credito){
        this.credito=credito;
    }
}

class Trabajador extends Persona{
    private float salario;

    public float getSalario(){
        return this.salario;
    }

    public void setSalario(float salario){
        this.salario=salario;
    }
}