package com.company;

public class Main {
    public static void main (String[] args){
        //Ejercicio 1
        int numeroif=-5;
        if (numeroif<0){
            System.out.println("El número es negativo");
        } else if (numeroif>0) {
            System.out.println("El número es positivo");
        }
        else {
            System.out.println("El número es cero");
        };

        //Ejercicio 2
        int numerowhile=0;
        while (numerowhile<3){
            System.out.print("El número es ");
            System.out.println(numerowhile);
            numerowhile++;
        };

        //Ejercicio 3
        do{
            System.out.print("El número es ");
            System.out.println(numerowhile);
            numerowhile++;
        }while (numerowhile<4);

        //Ejercicio 4
        for (int numerofor=0; numerofor<=3 ;numerofor++){
            System.out.print("El número es ");
            System.out.println(numerofor);
        };

        //Ejercicio 5
        String estacion="veran";
        switch(estacion) {
            case "verano":
                System.out.print("Nos encontramos en verano");
                break;
            case "invierno":
                System.out.print("Nos encontramos en invierno");
                break;
            case "otoño":
                System.out.print("Nos encontramos en otoño");
                break;
            case "primavera":
                System.out.print("Nos encontramos en primavera");
                break;
            default:
                System.out.print("Estación incorrecta");
        }
    }
}
