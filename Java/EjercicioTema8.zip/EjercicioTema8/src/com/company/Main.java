package com.company;

public class Main {
    public static void main (String[] args){

        Persona juan = new Persona();
        juan.setEdad(12);
        juan.setNombre("Juan");
        juan.setTelefono("955879487");

        System.out.println("El usuario "+juan.getNombre()+" tiene la edad de "+juan.getEdad()+
                " años y se le puede contactar mediante el número: "+ juan.getTelefono());
    }
}

class Persona{
    private int edad;
    private String nombre;
    private String telefono;

    public int getEdad(){
        return this.edad;
    }

    public String getNombre(){
        return this.nombre;
    }

    public String getTelefono(){
        return this.telefono;
    }

    public void setEdad(int edad){
        this.edad=edad;
    }

    public void setNombre(String nombre){
        this.nombre=nombre;
    }

    public void setTelefono(String telefono){
        this.telefono=telefono;
    }
}
