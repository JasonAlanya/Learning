package com.company;

public class Main {

    public static void main(String[] args){
        //Ejercicio 1
        sumar(1,2,3);

        //Ejercicio 2
        coche miCoche=new coche();

        miCoche.incrementarpuertas(1);
        System.out.println(miCoche.puertas);
    }

    public static  void sumar(int num1, int num2, int num3){
        int result;
        result=num1+num2+num3;

        System.out.println(result);
    }
}

class coche{
    public int puertas = 0;

    public void incrementarpuertas(int cantidad){
        this.puertas += cantidad;
    }

}
